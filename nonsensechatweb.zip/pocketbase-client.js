(function () {
  const SESSION_KEY = 'nonsense-pocketbase-session';
  const URL_KEY = 'nonsense-pocketbase-url';
  const PAGE_SIZE = 500;

  function cleanBase(url) {
    return String(url || '').replace(/\/+$/, '');
  }

  function parsedUrl(url) {
    try { return new URL(url, location.href); } catch (_) { return null; }
  }

  function isFirebaseHostingHost(hostname) {
    const host = String(hostname || '').toLowerCase();
    return host.endsWith('.web.app') || host.endsWith('.firebaseapp.com');
  }

  function isLocalOrLanHost(hostname) {
    const host = String(hostname || '').replace(/^\[|\]$/g, '').toLowerCase();
    return host === 'localhost'
      || host === '127.0.0.1'
      || host === '::1'
      || /^10\./.test(host)
      || /^192\.168\./.test(host)
      || /^172\.(1[6-9]|2\d|3[01])\./.test(host);
  }

  function isStaticHostingOrigin(url) {
    const parsed = parsedUrl(url);
    return !!(parsed && isFirebaseHostingHost(parsed.hostname));
  }

  function defaultBaseUrl(urlArg) {
    const configured = localStorage.getItem(URL_KEY) || window.NONSENSE_POCKETBASE_URL;
    if (configured && !isStaticHostingOrigin(configured)) return cleanBase(configured);
    if (urlArg && !/supabase\.co/i.test(String(urlArg))) return cleanBase(urlArg);

    if (location.protocol === 'http:' || location.protocol === 'https:') {
      const port = location.port;
      if (port === '8090') return location.origin;
      if (isFirebaseHostingHost(location.hostname)) return 'http://127.0.0.1:8090';
      if (isLocalOrLanHost(location.hostname)) return `http://${location.hostname}:8090`;
      if (!port) return location.origin;
      return `${location.protocol}//${location.hostname}:8090`;
    }

    return 'http://127.0.0.1:8090';
  }

  function safeId() {
    try { return crypto.randomUUID(); } catch (_) { return 'id' + Date.now() + Math.random().toString(36).slice(2, 10); }
  }

  function pbQuote(value) {
    return `"${String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;
  }

  function parseStoredSession() {
    try { return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null'); } catch (_) { return null; }
  }

  let API_BASE = defaultBaseUrl();
  let session = parseStoredSession();
  const authListeners = new Set();
  const tableListeners = {};
  const realtimeTopics = new Set();
  const topicHandlers = {};
  let realtimeSource = null;
  let realtimeClientId = '';
  let reconnectTimer = null;
  let realtimeStarting = false;
  let realtimeUnavailableWarned = false;

  function token() {
    return session && session.access_token;
  }

  function saveSession(next) {
    session = next;
    if (session) localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    else localStorage.removeItem(SESSION_KEY);
  }

  function emitAuth(event) {
    const payload = session ? { user: session.user, access_token: session.access_token } : null;
    authListeners.forEach((fn) => {
      try { fn(event || (session ? 'SIGNED_IN' : 'SIGNED_OUT'), payload); } catch (_) {}
    });
  }

  function apiError(json, status) {
    const data = json && json.data;
    let msg = (json && (json.message || json.error)) || `HTTP ${status}`;
    if (data && typeof data === 'object') {
      const first = Object.keys(data)[0];
      if (first && data[first] && data[first].message) msg = data[first].message;
    }
    const err = new Error(msg);
    err.status = status;
    err.response = json;
    return err;
  }

  async function api(path, opts) {
    opts = opts || {};
    const headers = Object.assign({}, opts.headers || {});
    let body = opts.body;
    if (body && !(body instanceof FormData) && typeof body !== 'string') {
      headers['Content-Type'] = headers['Content-Type'] || 'application/json';
      body = JSON.stringify(body);
    }
    if (token()) headers.Authorization = 'Bearer ' + token();
    const res = await fetch(API_BASE + path, Object.assign({}, opts, { headers, body }));
    if (res.status === 204) return {};
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw apiError(json, res.status);
    return json;
  }

  function getAt(obj, parts) {
    let cur = obj;
    for (const p of parts) {
      if (cur == null) return undefined;
      cur = cur[p];
    }
    return cur;
  }

  function setAt(obj, parts, value) {
    let cur = obj;
    for (let i = 0; i < parts.length - 1; i++) {
      const key = parts[i];
      if (!cur[key] || typeof cur[key] !== 'object' || Array.isArray(cur[key])) cur[key] = {};
      cur = cur[key];
    }
    cur[parts[parts.length - 1]] = value;
  }

  function deleteAt(obj, parts) {
    let cur = obj;
    for (let i = 0; i < parts.length - 1; i++) {
      cur = cur && cur[parts[i]];
      if (!cur || typeof cur !== 'object') return;
    }
    delete cur[parts[parts.length - 1]];
  }

  function deepEqual(a, b) {
    return JSON.stringify(a) === JSON.stringify(b);
  }

  function applyOps(doc, ops) {
    for (const op of ops || []) {
      const parts = op.path || [];
      if (op.op === 'set' && parts.length === 0) {
        for (const key of Object.keys(doc)) delete doc[key];
        Object.assign(doc, op.value || {});
        continue;
      }
      if (op.op === 'set') setAt(doc, parts, op.value);
      else if (op.op === 'serverNow') setAt(doc, parts, { __ts__: new Date().toISOString() });
      else if (op.op === 'delete') deleteAt(doc, parts);
      else if (op.op === 'increment') setAt(doc, parts, Number(getAt(doc, parts) || 0) + Number(op.value || 0));
      else if (op.op === 'arrayUnion') {
        const prev = Array.isArray(getAt(doc, parts)) ? getAt(doc, parts) : [];
        for (const item of op.value || []) if (!prev.some((x) => deepEqual(x, item))) prev.push(item);
        setAt(doc, parts, prev);
      } else if (op.op === 'arrayRemove') {
        const prev = Array.isArray(getAt(doc, parts)) ? getAt(doc, parts) : [];
        setAt(doc, parts, prev.filter((x) => !(op.value || []).some((item) => deepEqual(x, item))));
      }
    }
  }

  function tsValue(v) {
    if (v && typeof v === 'object' && typeof v.__ts__ === 'string') return v.__ts__;
    if (v instanceof Date) return v.toISOString();
    if (typeof v === 'string') return v;
    return '';
  }

  function deriveFields(table, docId, doc) {
    const data = { doc_id: docId, doc: doc || {} };
    if (table === 'users') {
      data.nick_lower = doc && doc.nickLower ? String(doc.nickLower) : '';
    } else if (table === 'chats') {
      data.members = Array.isArray(doc && doc.members) ? doc.members : [];
      data.type = doc && doc.type ? String(doc.type) : '';
      data.privacy = doc && doc.privacy ? String(doc.privacy) : '';
    } else if (table === 'messages') {
      data.chat_id = doc && doc.chat_id ? String(doc.chat_id) : '';
      data.at = tsValue(doc && doc.at);
      data.msg_type = doc && doc.type ? String(doc.type) : '';
    } else if (table === 'folders') {
      data.user_id = doc && doc.user_id ? String(doc.user_id) : '';
      data.ord = Number(doc && doc.order ? doc.order : 0);
    } else if (table === 'call_history') {
      data.chat_id = doc && doc.chat_id ? String(doc.chat_id) : '';
    } else if (table === 'friend_requests') {
      data.to_uid = doc && doc.to ? String(doc.to) : '';
    }
    return data;
  }

  function recordToRow(record) {
    const doc = record && record.doc && typeof record.doc === 'object' ? record.doc : {};
    return Object.assign({}, record, {
      id: record.doc_id || record.id,
      _pbId: record.id,
      doc
    });
  }

  function colValue(row, col) {
    const doc = row.doc || {};
    if (col === 'id') return row.id;
    if (col === 'members') return row.members != null ? row.members : doc.members;
    if (col === 'type' || col === 'msg_type') return row[col] != null ? row[col] : doc.type;
    if (col === 'privacy') return row.privacy != null ? row.privacy : doc.privacy;
    if (col === 'nick_lower') return row.nick_lower != null ? row.nick_lower : doc.nickLower;
    if (col === 'to_uid') return row.to_uid != null ? row.to_uid : doc.to;
    if (col === 'ord') return row.ord != null ? row.ord : doc.order;
    if (col === 'at') return row.at != null ? row.at : doc.at;
    if (col === 'chat_id') return row.chat_id != null ? row.chat_id : doc.chat_id;
    if (col === 'user_id') return row.user_id != null ? row.user_id : doc.user_id;
    const m = /^doc->>(.+)$/.exec(col);
    if (m) return doc[m[1]];
    return row[col] != null ? row[col] : doc[col];
  }

  function comparable(v) {
    if (v && typeof v === 'object' && typeof v.__ts__ === 'string') return new Date(v.__ts__).getTime();
    if (typeof v === 'string' && /^\d{4}-\d\d-\d\dT/.test(v)) return new Date(v).getTime();
    return v == null ? '' : v;
  }

  async function listAll(table) {
    const all = [];
    for (let page = 1; page < 1000; page++) {
      const res = await api(`/api/collections/${encodeURIComponent(table)}/records?page=${page}&perPage=${PAGE_SIZE}&skipTotal=1`);
      const items = res.items || [];
      all.push(...items.map(recordToRow));
      if (items.length < PAGE_SIZE) break;
    }
    return all;
  }

  async function findRecord(table, docId) {
    const filter = encodeURIComponent(`doc_id = ${pbQuote(docId)}`);
    try {
      const res = await api(`/api/collections/${encodeURIComponent(table)}/records?page=1&perPage=1&filter=${filter}&skipTotal=1`);
      if (res.items && res.items[0]) return res.items[0];
    } catch (_) {}

    if (/^[a-z0-9]{15}$/.test(String(docId))) {
      try { return await api(`/api/collections/${encodeURIComponent(table)}/records/${encodeURIComponent(docId)}`); } catch (_) {}
    }
    return null;
  }

  async function runQuery(state) {
    if (state.single && state.wheres.length === 1 && state.wheres[0].op === 'eq' && state.wheres[0].col === 'id') {
      const rec = await findRecord(state.table, state.wheres[0].val);
      return rec ? [recordToRow(rec)] : [];
    }

    let rows = await listAll(state.table);
    for (const w of state.wheres) {
      rows = rows.filter((row) => {
        const got = colValue(row, w.col);
        if (w.op === 'contains') return Array.isArray(got) && (w.val || []).every((x) => got.includes(x));
        return got === w.val;
      });
    }
    if (state.order) {
      const dir = state.order.ascending === false ? -1 : 1;
      rows.sort((a, b) => {
        const av = comparable(colValue(a, state.order.col));
        const bv = comparable(colValue(b, state.order.col));
        return av < bv ? -dir : av > bv ? dir : 0;
      });
    }
    if (state.limit != null) rows = rows.slice(0, Number(state.limit));
    return rows;
  }

  function makeQuery(table) {
    const state = { table, wheres: [], order: null, limit: null, single: false };
    const q = {
      select() { return q; },
      eq(col, val) { state.wheres.push({ op: 'eq', col, val }); return q; },
      contains(col, val) { state.wheres.push({ op: 'contains', col, val }); return q; },
      order(col, opts) { state.order = { col, ascending: !(opts && opts.ascending === false) }; return q; },
      limit(n) { state.limit = n; return q; },
      maybeSingle() { state.single = true; return q; },
      then(resolve) {
        runQuery(state)
          .then((rows) => resolve({ data: state.single ? (rows[0] || null) : rows, error: null }))
          .catch((e) => resolve({ data: state.single ? null : [], error: { message: e.message, status: e.status } }));
      }
    };
    return q;
  }

  function emitTable(table, record, action) {
    const row = record ? recordToRow(record) : null;
    const payload = action === 'delete' ? { old: row || {}, new: null } : { old: {}, new: row || {} };
    (tableListeners[table] || []).forEach((fn) => {
      try { fn(payload); } catch (_) {}
    });
  }

  function addTopicHandler(table, topic) {
    if (!realtimeSource || topicHandlers[topic]) return;
    const handler = (event) => {
      let data = {};
      try { data = JSON.parse(event.data || '{}'); } catch (_) {}
      emitTable(table, data.record, data.action);
    };
    topicHandlers[topic] = handler;
    realtimeSource.addEventListener(topic, handler);
  }

  async function submitRealtimeSubscriptions() {
    if (!realtimeClientId || !realtimeTopics.size) return;
    await api('/api/realtime', {
      method: 'POST',
      body: {
        clientId: realtimeClientId,
        subscriptions: Array.from(realtimeTopics)
      }
    }).catch(() => {});
  }

  async function pocketBaseReady() {
    try {
      const res = await fetch(API_BASE + '/api/collections/users', {
        headers: token() ? { Authorization: 'Bearer ' + token(), Accept: 'application/json' } : { Accept: 'application/json' }
      });
      const type = res.headers.get('content-type') || '';
      return type.includes('application/json') && (res.ok || res.status === 401 || res.status === 403 || res.status === 404);
    } catch (_) {
      return false;
    }
  }

  function startRealtime() {
    if (realtimeSource || realtimeStarting || typeof EventSource === 'undefined') return;
    clearTimeout(reconnectTimer);
    realtimeStarting = true;
    pocketBaseReady().then((ready) => {
      realtimeStarting = false;
      if (!ready) {
        if (!realtimeUnavailableWarned) {
          realtimeUnavailableWarned = true;
          console.warn(`PocketBase realtime endpoint is unavailable at ${API_BASE}. Start PocketBase with npm run pb, or use ?backend=local with npm run server.`);
        }
        reconnectTimer = setTimeout(startRealtime, 2500);
        return;
      }
      realtimeUnavailableWarned = false;
      realtimeSource = new EventSource(API_BASE + '/api/realtime');
      realtimeSource.addEventListener('PB_CONNECT', (event) => {
        realtimeClientId = event.lastEventId || '';
        if (!realtimeClientId) {
          try { realtimeClientId = JSON.parse(event.data || '{}').clientId || ''; } catch (_) {}
        }
        for (const topic of realtimeTopics) addTopicHandler(topic.split('/')[0], topic);
        submitRealtimeSubscriptions();
      });
      realtimeSource.onerror = () => {
        try { realtimeSource.close(); } catch (_) {}
        realtimeSource = null;
        realtimeClientId = '';
        reconnectTimer = setTimeout(startRealtime, 1200);
      };
    });
  }

  function registerRealtime(table, cb) {
    tableListeners[table] = tableListeners[table] || [];
    tableListeners[table].push(cb);
    const topic = `${table}/*`;
    realtimeTopics.add(topic);
    startRealtime();
    addTopicHandler(table, topic);
    submitRealtimeSubscriptions();
    return () => {
      const arr = tableListeners[table] || [];
      const i = arr.indexOf(cb);
      if (i >= 0) arr.splice(i, 1);
    };
  }

  async function docApply(table, docId, ops) {
    let record = await findRecord(table, docId);
    if (!record && table === 'users') {
      saveSession(null);
      throw new Error('PocketBase auth session is invalid. Please sign in again.');
    }
    const doc = record && record.doc && typeof record.doc === 'object' ? JSON.parse(JSON.stringify(record.doc)) : {};
    applyOps(doc, ops || []);
    const body = deriveFields(table, docId, doc);
    if (record) {
      record = await api(`/api/collections/${encodeURIComponent(table)}/records/${encodeURIComponent(record.id)}`, {
        method: 'PATCH',
        body
      });
    } else {
      record = await api(`/api/collections/${encodeURIComponent(table)}/records`, {
        method: 'POST',
        body
      });
    }
    emitTable(table, record, 'update');
    return record;
  }

  async function docDelete(table, docId) {
    const record = await findRecord(table, docId);
    if (!record) return;
    await api(`/api/collections/${encodeURIComponent(table)}/records/${encodeURIComponent(record.id)}`, { method: 'DELETE' });
    emitTable(table, record, 'delete');
  }

  function mapAuthErr(error) {
    const m = (error && error.message || '').toLowerCase();
    if (/already|unique|exists|registered/.test(m)) return { message: error.message, code: 'auth/email-already-in-use' };
    if (/invalid|failed|password|identity/.test(m)) return { message: error.message, code: 'auth/invalid-credential' };
    if (/short|length|weak|least/.test(m)) return { message: error.message, code: 'auth/weak-password' };
    return { message: error.message || 'auth error', code: error.code || error.status || 'auth/error' };
  }

  function authDataFromRecord(tokenValue, record) {
    if (!record) return { access_token: tokenValue, user: { id: '', email: '' }, record: {} };
    return {
      access_token: tokenValue,
      user: { id: record.id || '', email: record.email || '' },
      record
    };
  }

  async function refreshSession() {
    if (!session || !session.access_token || !session.user || !session.user.id) {
      saveSession(null);
      return null;
    }
    try {
      const r = await api('/api/collections/users/auth-refresh', { method: 'POST' });
      const next = authDataFromRecord(r.token, r.record);
      if (!next.user.id) throw new Error('Invalid PocketBase session');
      saveSession(next);
      return next;
    } catch (_) {
      saveSession(null);
      return null;
    }
  }

  const client = {
    auth: {
      async signUp({ email, password }) {
        try {
          await api('/api/collections/users/records', {
            method: 'POST',
            body: {
              email,
              emailVisibility: true,
              password,
              passwordConfirm: password,
              doc_id: 'pending_' + safeId(),
              doc: {},
              nick_lower: ''
            }
          });
          return await this.signInWithPassword({ email, password });
        } catch (e) {
          return { data: {}, error: mapAuthErr(e) };
        }
      },
      async signInWithPassword({ email, password }) {
        try {
          const r = await api('/api/collections/users/auth-with-password', {
            method: 'POST',
            body: { identity: email, password }
          });
          const next = authDataFromRecord(r.token, r.record);
          saveSession(next);
          emitAuth('SIGNED_IN');
          return { data: { session: next, user: next.user }, error: null };
        } catch (e) {
          return { data: {}, error: mapAuthErr(e) };
        }
      },
      async getSession() {
        const current = await refreshSession();
        return { data: { session: current }, error: null };
      },
      onAuthStateChange(cb) {
        authListeners.add(cb);
        setTimeout(async () => cb('INITIAL_SESSION', await refreshSession()), 0);
        return { data: { subscription: { unsubscribe() { authListeners.delete(cb); } } } };
      },
      async signOut() {
        saveSession(null);
        emitAuth('SIGNED_OUT');
        submitRealtimeSubscriptions();
        return { error: null };
      }
    },
    realtime: { setAuth() { submitRealtimeSubscriptions(); } },
    from: makeQuery,
    channel() {
      const handlers = [];
      return {
        on(_kind, cfg, cb) {
          if (cfg && cfg.table && cb) handlers.push({ table: cfg.table, cb });
          return this;
        },
        subscribe() {
          handlers.forEach((h) => registerRealtime(h.table, h.cb));
          return this;
        }
      };
    },
    async rpc(name, args) {
      try {
        if (name === 'doc_apply') {
          const data = await docApply(args._table, args._id, args._ops || []);
          return { data, error: null };
        }
        if (name === 'doc_delete') {
          await docDelete(args._table, args._id);
          return { data: null, error: null };
        }
        if (name === 'doc_apply_batch') {
          for (const item of args._items || []) await docApply(item.table, item.id, item.ops || []);
          return { data: null, error: null };
        }
        return { data: null, error: { message: 'Unknown RPC ' + name } };
      } catch (e) {
        return { data: null, error: { message: e.message, status: e.status } };
      }
    }
  };

  function upload(file, onProgress, onXhr) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      onXhr && onXhr(xhr);
      xhr.open('POST', API_BASE + '/api/collections/uploads/records');
      if (token()) xhr.setRequestHeader('Authorization', 'Bearer ' + token());
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable && onProgress) onProgress(e.loaded / e.total);
      };
      xhr.onload = () => {
        let json = {};
        try { json = JSON.parse(xhr.responseText || '{}'); } catch (e) { reject(e); return; }
        if (xhr.status < 200 || xhr.status >= 300) {
          reject(apiError(json, xhr.status));
          return;
        }
        const fileName = Array.isArray(json.file) ? json.file[0] : json.file;
        if (!fileName) {
          reject(new Error('PocketBase upload did not return a file name'));
          return;
        }
        const collection = json.collectionName || 'uploads';
        resolve(`${API_BASE}/api/files/${encodeURIComponent(collection)}/${encodeURIComponent(json.id)}/${encodeURIComponent(fileName)}`);
      };
      xhr.onerror = () => reject(new Error('Network error'));
      xhr.onabort = () => reject(Object.assign(new Error('aborted'), { aborted: true }));
      const fd = new FormData();
      fd.set('file', file, file.name || ('upload_' + safeId()));
      fd.set('owner', session && session.user ? session.user.id : '');
      onProgress && onProgress(0);
      xhr.send(fd);
    });
  }

  window.NonsensePocketBase = {
    apiBase: API_BASE,
    setUrl(url) {
      localStorage.setItem(URL_KEY, cleanBase(url));
      location.reload();
    }
  };
  window.NonsenseLocalBackend = { apiBase: API_BASE, upload };
  window.supabase = {
    createClient(url) {
      API_BASE = defaultBaseUrl();
      window.NonsensePocketBase.apiBase = API_BASE;
      window.NonsenseLocalBackend.apiBase = API_BASE;
      return client;
    }
  };
})();
